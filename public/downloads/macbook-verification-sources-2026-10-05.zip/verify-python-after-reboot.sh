#!/bin/zsh
set -e
source "$HOME/.zprofile"
cd "$HOME/Developer/research-python-baseline"
uv --version
python3.13 --version
uv sync --locked --offline
uv run --locked --offline research-python-baseline
