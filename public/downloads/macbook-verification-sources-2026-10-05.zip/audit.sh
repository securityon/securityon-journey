#!/bin/sh
sanitize() {
  sed -E '/Serial Number|Hardware UUID|Provisioning UDID/d; s@/Users/[^/[:space:]]+@/Users/<redacted>@g; s/[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9:.]+ system_profiler\[[^]]+\]/system_profiler/g'
}
run() {
  printf '\n### `%s`\n\n```text\n' "$*"
  "$@" 2>&1 | sanitize
  printf '```\n'
}
printf '# macOS 연구 워크스테이션 읽기 전용 점검\n\n점검일: 2026-10-04 (Asia/Seoul). 설치·설정 변경 없음. 명령은 현재 Codex 실행 환경에서 수행. 기기 식별자와 사용자 경로는 제거·가림.\n'
run /usr/bin/uname -s
run /usr/bin/sw_vers
run /usr/bin/uname -m
run /usr/sbin/system_profiler SPHardwareDataType
run /usr/sbin/sysctl -n hw.model hw.machine hw.memsize hw.physicalcpu hw.logicalcpu
run /bin/df -h / /System/Volumes/Data
run /usr/sbin/diskutil info /
run /usr/bin/fdesetup status
run /usr/bin/xcode-select -p
run /usr/bin/xcrun --find clang
run /usr/sbin/pkgutil --pkg-info com.apple.pkg.CLTools_Executables
printf '\n### 개발도구 PATH 탐색 (`command -v`)\n\n```text\n'
for tool in git gh brew python3 python node npm npx uv pip3 ruby clang make docker conda code; do
  found=$(command -v "$tool" 2>/dev/null)
  if [ -n "$found" ]; then printf '%s: %s\n' "$tool" "$found"; else printf '%s: PATH에서 발견되지 않음\n' "$tool"; fi
done | sanitize
printf '```\n\n### 표준 설치 위치 존재 여부 (`test -e`)\n\n```text\n'
for location in /Applications/Xcode.app /Library/Developer/CommandLineTools /opt/homebrew/bin/brew /usr/local/bin/brew /Applications/Docker.app '/Applications/Google Drive.app'; do
  if [ -e "$location" ]; then printf '%s: 존재\n' "$location"; else printf '%s: 없음 또는 접근 불가\n' "$location"; fi
done
printf '```\n'
run /usr/bin/git --version
run /usr/bin/ruby --version
