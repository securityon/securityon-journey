# MacBook verification source bundle

Source snapshot for the command-reference Note, 2026-10-05.
Extract the three project directories into ~/Developer only if those names do
not already exist. Do not overwrite existing work. Install the recorded uv and
managed Python, then run uv sync --locked from each project. Scripts sourcing
~/.zprofile require the tool paths described in the Note.

Includes original verification code, Python pins and dependency records.
Notebook outputs were cleared in this export; code cells remain unchanged.
No virtual environments, model weights, credentials, caches or execution results.
LLM model download requires network access and approximately 0.93 GB of model
files in addition to dependencies. GPU scripts require a normal macOS login
session with Metal access. Original AI verification deliberately fails on
MLX default precision on the recorded machine; use run-mlx-comparison.sh for
observations and the separate MLX_ENABLE_TF32=0 check.

Runs overwrite their named result files. Preserve earlier results first.
The LLM run completed but some source citations were wrong: completion is not
a factual correctness test. No fresh Mac installation or fresh GPU/LLM
environment reconstruction is certified by this source export.

Research project README files are replaced with concise export instructions;
earlier GitHub preservation plans are not included. The test projects do not have separate GitHub
repositories. Public Note excerpts in corpus.json belong to this journal.
