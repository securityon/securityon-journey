#!/bin/zsh
set -eu
set -o pipefail
source "$HOME/.zprofile"
cd "$HOME/Developer/research-apple-silicon-ai"
mkdir -p results
unset MLX_ENABLE_TF32
uv run --locked --offline python verify_ai.py mlx --observe-precision 2>&1 | tee results/mlx-default-run.log
MLX_ENABLE_TF32=0 uv run --locked --offline python verify_ai.py mlx 2>&1 | tee results/mlx-full-fp32-run.log
printf '\nMLX comparison completed. Results saved under results/.\n'
