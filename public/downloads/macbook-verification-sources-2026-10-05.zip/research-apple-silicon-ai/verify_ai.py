import argparse
import importlib.metadata as metadata
import json
import os
import platform
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('framework', choices=['torch', 'mlx'])
parser.add_argument('--observe-precision', action='store_true')
args = parser.parse_args()
report = {'framework': args.framework, 'python': platform.python_version(), 'architecture': platform.machine(), 'executable': sys.executable.replace(str(Path.home()), '~'), 'prefix': sys.prefix.replace(str(Path.home()), '~'), 'numpy': np.__version__, 'fallback_env': os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK', 'unset'), 'precision_tests': [], 'mlx_enable_tf32': os.environ.get('MLX_ENABLE_TF32','unset')}
assert Path(sys.prefix) == ROOT / '.venv'
assert platform.machine() == 'arm64'
rng = np.random.default_rng(20261005)
a = rng.uniform(-1, 1, (128, 128)).astype(np.float32)
b = rng.uniform(-1, 1, (128, 128)).astype(np.float32)
reference = a.astype(np.float64) @ b.astype(np.float64)
x_np = np.linspace(-1, 1, 128, dtype=np.float32)
y_np = 2 * x_np + 1

if args.framework == 'torch':
    import torch
    report['version'] = torch.__version__
    report['mps_built'] = torch.backends.mps.is_built()
    report['mps_available'] = torch.backends.mps.is_available()
    assert report['mps_available'], 'MPS GPU is unavailable in this execution context'
    assert os.environ.get('PYTORCH_ENABLE_MPS_FALLBACK') not in ('1', 'true')
    device = torch.device('mps')
    report['device'] = str(device)
    small = torch.tensor([[1., 2.], [3., 4.]], device=device) @ torch.tensor([[5., 6.], [7., 8.]], device=device)
    np.testing.assert_array_equal(small.cpu().numpy(), [[19, 22], [43, 50]])
    report['known_matmul'] = small.cpu().tolist()
    for name, dtype, rtol, atol in [('float32',torch.float32,1e-4,1e-4), ('float16',torch.float16,5e-3,2e-2)]:
        result = torch.tensor(a, dtype=dtype, device=device) @ torch.tensor(b, dtype=dtype, device=device)
        torch.mps.synchronize()
        actual = result.cpu().float().numpy()
        np.testing.assert_allclose(actual, reference, rtol=rtol, atol=atol)
        report['precision_tests'].append({'dtype':name,'shape':[128,128],'device':str(result.device),'max_abs_error':float(np.max(np.abs(actual-reference))),'rtol':rtol,'atol':atol,'passed':True})
    def train(target):
        x=torch.tensor(x_np,device=target); y=torch.tensor(y_np,device=target)
        p=torch.zeros(2,device=target,requires_grad=True)
        losses=[]; first_grad=None
        for step in range(101):
            loss=((p[0]*x+p[1]-y)**2).mean()
            losses.append(float(loss.item()))
            if step == 100: break
            loss.backward()
            if step==0: first_grad=p.grad.detach().cpu().tolist()
            with torch.no_grad(): p -= .1 * p.grad
            p.grad.zero_()
        return {'initial_loss':losses[0],'final_loss':losses[-1],'parameters':p.detach().cpu().tolist(),'initial_gradient':first_grad,'steps':100,'learning_rate':.1}
    report['training_gpu']=train('mps'); report['training_cpu']=train('cpu')
    try:
        torch.tensor([1.], dtype=torch.float64, device=device)
        report['float64_probe']={'supported':True}
    except (TypeError, RuntimeError) as e:
        report['float64_probe']={'supported':False,'error':str(e)}
    torch.mps.synchronize()
    report['memory_bytes']={'current_allocated':torch.mps.current_allocated_memory(),'driver_allocated':torch.mps.driver_allocated_memory(),'recommended_max':torch.mps.recommended_max_memory()}
else:
    import mlx.core as mx
    report['version']=metadata.version('mlx')
    report['metal_available']=mx.metal.is_available(); assert report['metal_available']
    report['device_info']=mx.device_info()
    mx.set_default_device(mx.gpu)
    mx.reset_peak_memory()
    report['device']=str(mx.default_device())
    small=mx.matmul(mx.array([[1.,2.],[3.,4.]]),mx.array([[5.,6.],[7.,8.]]),stream=mx.gpu)
    mx.eval(small)
    np.testing.assert_array_equal(np.array(small),[[19,22],[43,50]])
    report['known_matmul']=small.tolist()
    for name,dtype,rtol,atol in [('float32',mx.float32,1e-4,1e-4),('float16',mx.float16,5e-3,2e-2)]:
        aa=mx.array(a,dtype=dtype); bb=mx.array(b,dtype=dtype)
        gpu=mx.matmul(aa,bb,stream=mx.gpu); cpu=mx.matmul(aa,bb,stream=mx.cpu)
        mx.eval(gpu,cpu)
        actual=np.array(gpu).astype(np.float32)
        passed=bool(np.allclose(actual,reference,rtol=rtol,atol=atol))
        cpu_passed=bool(np.allclose(actual,np.array(cpu).astype(np.float32),rtol=rtol,atol=atol))
        if not args.observe_precision:
            np.testing.assert_allclose(actual,reference,rtol=rtol,atol=atol)
            np.testing.assert_allclose(actual,np.array(cpu).astype(np.float32),rtol=rtol,atol=atol)
        report['precision_tests'].append({'dtype':name,'shape':[128,128],'stream':'gpu','max_abs_error':float(np.max(np.abs(actual-reference))),'cpu_gpu_max_abs_error':float(np.max(np.abs(actual-np.array(cpu)))),'rtol':rtol,'atol':atol,'passed':passed,'cpu_gpu_passed':cpu_passed})
    def train(target):
        with mx.stream(target):
            x=mx.array(x_np); y=mx.array(y_np); p=mx.zeros(2)
            def loss_fn(params): return mx.mean((params[0]*x+params[1]-y)**2)
            value_grad=mx.value_and_grad(loss_fn)
            losses=[]; first_grad=None
            for step in range(101):
                loss,grad=value_grad(p); mx.eval(loss,grad)
                losses.append(float(loss.item()))
                if step==0: first_grad=grad.tolist()
                if step==100: break
                p=p-.1*grad; mx.eval(p)
            return {'initial_loss':losses[0],'final_loss':losses[-1],'parameters':p.tolist(),'initial_gradient':first_grad,'steps':100,'learning_rate':.1}
    report['training_gpu']=train(mx.gpu); report['training_cpu']=train(mx.cpu)
    mx.synchronize()
    report['memory_bytes']={'active':mx.get_active_memory(),'cache':mx.get_cache_memory(),'peak':mx.get_peak_memory()}

for key in ['training_gpu','training_cpu']:
    t=report[key]
    assert t['final_loss'] < 1e-5
    np.testing.assert_allclose(t['parameters'],[2,1],rtol=1e-3,atol=1e-3)
np.testing.assert_allclose(report['training_gpu']['parameters'],report['training_cpu']['parameters'],rtol=1e-4,atol=1e-4)
report['all_checks_passed']=all(t['passed'] for t in report['precision_tests'])
(ROOT/'results').mkdir(exist_ok=True)
label=args.framework if args.framework=='torch' else ('mlx-full-fp32' if os.environ.get('MLX_ENABLE_TF32')=='0' else 'mlx-default')
output=ROOT/'results'/(label+'-verification.json')
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
