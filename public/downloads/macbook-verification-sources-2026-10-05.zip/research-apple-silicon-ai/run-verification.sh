#!/bin/zsh
set -eu
set -o pipefail
source "$HOME/.zprofile"
cd "$HOME/Developer/research-apple-silicon-ai"
mkdir -p results
uv sync --locked
unset PYTORCH_ENABLE_MPS_FALLBACK
uv run --locked python verify_ai.py torch 2>&1 | tee results/torch-run.log
uv run --locked python verify_ai.py mlx 2>&1 | tee results/mlx-run.log
printf '\nGPU verification completed. Results saved under results/.\n'
