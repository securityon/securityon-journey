import os, json, hashlib, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['HF_HOME']=str(ROOT/'.runtime/hf-home')
os.environ['HF_HUB_DISABLE_TELEMETRY']='1'
from huggingface_hub import snapshot_download
repo='Qwen/Qwen3-1.7B-MLX-4bit'
revision='21457c6f51ed54a7c16e988c0844db973815c137'
meta=json.load(urllib.request.urlopen(f'https://huggingface.co/api/models/{repo}/revision/{revision}?blobs=true'))
files=[f['rfilename'] for f in meta['siblings'] if not f['rfilename'].startswith('.')]
location=ROOT/'models/qwen3-1.7b-4bit'
snapshot_download(repo, revision=revision, local_dir=location, cache_dir=ROOT/'.runtime/hf-cache', allow_patterns=files, token=False)
records=[]
for item in meta['siblings']:
 if item['rfilename'] not in files: continue
 p=location/item['rfilename']; h=hashlib.sha256()
 with p.open('rb') as fp:
  for block in iter(lambda:fp.read(1024*1024),b''):h.update(block)
 digest=h.hexdigest();expected=item.get('lfs',{}).get('sha256')
 assert p.stat().st_size==item['size']
 if expected:assert digest==expected
 records.append(dict(file=item['rfilename'],bytes=p.stat().st_size,sha256=digest,expected_lfs_sha256=expected,lfs_match=digest==expected if expected else None))
manifest=dict(repository=repo,revision=revision,license=meta.get('cardData',{}).get('license'),total_bytes=sum(x['bytes'] for x in records),files=records)
(ROOT/'model-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
