# -*- coding: utf-8 -*-
import os,json,time,math,re,sys,platform,hashlib
from collections import Counter
from pathlib import Path
from importlib.metadata import version
ROOT=Path(__file__).resolve().parent
os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',HF_HOME=str(ROOT/'.runtime/hf-home'))
def grams(text):
 text=re.sub(r'\s+',' ',text.lower());return Counter(text[i:i+2] for i in range(len(text)-1))
def retrieve(query,docs):
 q=grams(query); out=[]
 for d in docs:
  c=grams(d['title']+' '+d['text']); dot=sum(q[k]*c[k] for k in q)
  score=dot/(math.sqrt(sum(v*v for v in q.values()))*math.sqrt(sum(v*v for v in c.values())))
  out.append(dict(id=d['id'],score=score,title=d['title'],url=d['url'],text=d['text']))
 return sorted(out,key=lambda d:d['score'],reverse=True)[:2]
cases=[('folders','코드와 연구자료를 각각 어느 폴더에서 관리하며 Research는 Google Drive 어디에 동기화하나요?'),('calculation','1부터 5까지의 제곱값을 검증할 때 예상하는 합계와 평균은 얼마인가요?'),('precision','MLX float32 기준 검증에 명시하기로 한 환경변수 설정은 무엇인가요?'),('missing','이 MacBook에서 70B 모델을 실행했을 때 평균 생성 속도는 몇 토큰/초인가요?')]
docs=json.loads((ROOT/'corpus.json').read_text())
if '--retrieval-only' in sys.argv:
 print(json.dumps({key:[{'id':d['id'],'score':d['score']} for d in retrieve(q,docs)] for key,q in cases},ensure_ascii=False,indent=2));sys.exit()
import mlx.core as mx
from mlx_lm import load,stream_generate
from mlx_lm.sample_utils import make_sampler
out=ROOT/'results';out.mkdir(exist_ok=True)
start=time.perf_counter();model,tokenizer=load(str(ROOT/'models/qwen3-1.7b-4bit'),trust_remote_code=False);load_s=time.perf_counter()-start
manifest=json.loads((ROOT/'model-manifest.json').read_text())
report=dict(model_repository=manifest['repository'],revision=manifest['revision'],python=platform.python_version(),architecture=platform.machine(),packages={n:version(n) for n in ['mlx','mlx-metal','mlx-lm','transformers','numpy','huggingface-hub']},model_load_seconds=load_s,device=str(mx.default_device()),settings=dict(enable_thinking=False,empty_think_prefix=True,temperature=0,max_new_tokens=256,prompt_limit_tokens=2048,mlx_enable_tf32=os.getenv('MLX_ENABLE_TF32'),offline_env=True),corpus_sha256=hashlib.sha256((ROOT/'corpus.json').read_bytes()).hexdigest(),uv_lock_sha256=hashlib.sha256((ROOT/'uv.lock').read_bytes()).hexdigest(),cases=[])
def run(key,query,evidence=None):
 if evidence is None:
  messages=[dict(role='user',content=query)]
 else:
  context='\n\n'.join(f"[{d['id']}] {d['title']}\n{d['text']}" for d in evidence)
  messages=[dict(role='system',content='당신은 연구기록을 확인하는 도우미입니다. 아래 자료에 있는 사실만 사용하세요. 답은 짧은 한국어로 쓰고 근거를 [D1]처럼 표시하세요. 답에 필요한 정보가 자료에 없으면 정확히 자료에서 확인할 수 없습니다 라고 답하세요. 추측하거나 없는 숫자를 만들지 마세요.'),dict(role='user',content=f'자료:\n{context}\n\n질문: {query}')]
 rendered=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=False)
 # This pinned template does not implement enable_thinking. Supply an empty
 # completed reasoning block in the prompt; preserve original downloaded files.
 rendered += '<think>\n\n</think>\n\n'
 tokens=tokenizer.encode(rendered,add_special_tokens=False)
 assert len(tokens)<=2048,len(tokens)
 started=time.perf_counter();pieces=[];last=None
 for r in stream_generate(model,tokenizer,tokens,max_tokens=256,sampler=make_sampler(temp=0)):
  pieces.append(r.text);last=r
 answer=''.join(pieces).strip(); assert last is not None
 record=dict(id=key,question=query,retrieved=evidence,answer=answer,citations=re.findall(r'\[D[0-9]+\]',answer),prompt_tokens=last.prompt_tokens,generation_tokens=last.generation_tokens,finish_reason=last.finish_reason,elapsed_seconds=time.perf_counter()-started,prompt_tokens_per_second=last.prompt_tps,generation_tokens_per_second=last.generation_tps,mlx_peak_memory_gb=last.peak_memory)
 report['cases'].append(record);(out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items() if k!='retrieved'},ensure_ascii=False),flush=True)
run('smoke','2 + 3의 결과를 숫자 하나로만 답하세요.')
for key,query in cases:run(key,query,retrieve(query,docs))
report['complete']=True;(out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('검증 실행 완료: results/verification.json',flush=True)
