# -*- coding: utf-8 -*-
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent
notes=Path.home()/'Developer/securityon-journey/src/content/notes'
def paras(file,terms):
 text=(notes/file).read_text();return '\n\n'.join(p for p in text.split('\n\n') if not p.startswith('|') and any(t in p for t in terms))
docs=[dict(id='D1',title='macOS와 연구자료 관리의 기준 상태',url='https://journey.securityon.org/notes/ko/macos-research-materials-baseline/',text=paras('2026-10-04-macos-research-materials-baseline.md',['코드 작업 위치는','Google Drive에서는 로컬'])),dict(id='D2',title='MacBook의 Python·Jupyter 연구환경',url='https://journey.securityon.org/notes/ko/macbook-python-jupyter/',text=paras('2026-10-04-macbook-python-jupyter.md',['검증 코드는 1부터'])),dict(id='D3',title='Apple Silicon AI 환경 검증',url='https://journey.securityon.org/notes/ko/macbook-apple-silicon-ai/',text=paras('2026-10-05-macbook-apple-silicon-ai.md',['MLX의 첫 float32','이번 단계에서는 GPU 접근']))]
(root/'corpus.json').write_text(json.dumps(docs,ensure_ascii=False,indent=2)+'\n')
print([(d['id'],len(d['text'])) for d in docs])
