#!/bin/zsh
set -euo pipefail
source "$HOME/.zprofile"
cd "$HOME/Developer/research-local-llm"
mkdir -p results
export HF_HOME="$PWD/.runtime/hf-home"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1
MLX_ENABLE_TF32=0 uv run --locked --offline python verify_llm.py 2>&1 | tee results/terminal.log
