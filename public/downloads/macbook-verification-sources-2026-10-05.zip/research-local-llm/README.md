# research-local-llm

Exported verification source, 2026-10-05. See the companion MacBook
command-reference Note for prerequisites, execution and observed limitations.
Run uv sync --locked from this directory before verification.
Preserve earlier results before rerunning; named result files are overwritten.
