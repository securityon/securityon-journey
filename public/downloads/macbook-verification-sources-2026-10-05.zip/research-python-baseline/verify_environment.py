import json
from research_python_baseline import run_baseline

print(json.dumps(run_baseline("vscode-terminal"), indent=2))
