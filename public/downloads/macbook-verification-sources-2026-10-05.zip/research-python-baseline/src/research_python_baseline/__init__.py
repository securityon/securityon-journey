import json
import os
import platform
import sys
from importlib.metadata import version
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
os.environ.setdefault("MPLCONFIGDIR", str(PROJECT / ".runtime" / "matplotlib"))


def run_baseline(label="terminal"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    assert Path(sys.prefix).resolve() == (PROJECT / ".venv").resolve()
    assert platform.machine() == "arm64"
    assert sys.version_info[:2] == (3, 13)
    x = np.arange(1, 6, dtype=np.int64)
    table = pd.DataFrame({"x": x, "square": x ** 2})
    total = int(table["square"].sum())
    mean = float(table["square"].mean())
    assert total == 55 and mean == 11.0
    output = PROJECT / "results" / label
    output.mkdir(parents=True, exist_ok=True)
    table.to_csv(output / "squares.csv", index=False)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(table["x"], table["square"], marker="o")
    ax.set(xlabel="x", ylabel="x squared", title="Python research baseline")
    fig.tight_layout()
    fig.savefig(output / "squares.png", dpi=150)
    plt.close(fig)
    result = {
        "python": platform.python_version(),
        "architecture": platform.machine(),
        "executable": sys.executable.replace(str(Path.home()), "~"),
        "prefix": sys.prefix.replace(str(Path.home()), "~"),
        "environment_ok": True,
        "versions": {name: version(name) for name in ["numpy", "pandas", "matplotlib", "ipykernel", "jupyterlab", "nbconvert"]},
        "sum": total,
        "mean": mean,
        "output": str(output.relative_to(PROJECT)),
    }
    (output / "baseline.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    print(json.dumps(run_baseline(), indent=2))
